#!/usr/bin/env python3
# Model loader for team member
import torch
import json
import os

def load_a2c_model(zip_path):
    """Load A2C model from zip file"""
    import zipfile
    
    # Extract model files
    with zipfile.ZipFile(zip_path, 'r') as zipf:
        zipf.extractall('extracted_model')
    
    # Load metadata
    with open('extracted_model/metadata.json', 'r') as f:
        metadata = json.load(f)
    
    # Load actor weights
    actor_weights = torch.load('extracted_model/actor.pth')
    
    print(f"Model loaded successfully!")
    print(f"State dimension: {metadata['state_dim']}")
    print(f"Action dimension: {metadata['action_dim']}")
    
    return actor_weights, metadata

# Usage example:
# actor_weights, metadata = load_a2c_model('your_model.zip')
